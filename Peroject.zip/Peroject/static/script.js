const imageUpload = document.getElementById('imageUpload');
const extractTextButton = document.getElementById('extractTextButton');
const analyzeButton = document.getElementById('analyzeButton');
const ingredientText = document.getElementById('ingredientText');
let extractedText = '';

// Predefined pros and cons for each image
const imageProsAndCons = {
    'img1.jpg': {
        pros: ['1. **Cleansing agents**: Ingredients like **Ammonium Lauryl Sulfate**, **Decyl Glucoside**, and **Cocamidopropyl Betaine** effectively clean and remove dirt or oils from the skin or hair.','2. **Moisturizing**: **Glycerin** is a great humectant that helps to retain moisture in the skin or hair, preventing dryness.','3. **Conditioning**: Ingredients like **Polyquaternium-7**, **Dimethicone**, and **Amodimethicone** are commonly used to improve texture, smoothness, and shine, making hair or skin feel soft and silky.','4. **Fragrance and freshness**: Fragrance and extracts like **Cicer Arietinum Seed Extract** provide a pleasant scent and potential antioxidant benefits.','5. **Preservatives**: **Potassium Sorbate** and **Sodium Benzoate** help to extend shelf life and prevent bacterial growth in the product.'],
        cons: ['1. **Sulfates (Ammonium Lauryl Sulfate)**: These can be harsh on sensitive skin, stripping it of natural oils and leading to dryness or irritation.','2. **Synthetic Fragrance**: Fragrances may contain allergens or irritants that can cause allergic reactions or skin sensitivities.','3. **Methylchloroisothiazolinone & Methylisothiazolinone**: These preservatives are known to cause allergic reactions or skin irritation in some individuals.','4. **PEGs**: PEG compounds like **PEG-150 Distearate** and **PEG-45M** are petrochemical derivatives, which may not be ideal for those avoiding synthetic chemicals.','5. **Environmental Impact**: Ingredients like **Dimethicone** and **Acrylates Copolymer** are non-biodegradable and may harm aquatic life.']
    },
    'img2.jpg': {
        pros: ['1. **Moisturizing**: **Coconut oil** and **Sweet almond oil** provide nourishing fatty acids, which moisturize and soothe the skin or hair.','2. **Cleansing agents**: **Sodium laureth sulfate** and **Cocamidopropyl betaine** are effective in removing impurities and oils.','3. **Conditioning**: **Panthenol** and **Polyquaternium-10** are used to improve hair manageability and smoothness.','4. **Preservatives**: **Phenoxyethanol** and **Methylparaben** ensure the product stays free from microbial contamination and maintains its shelf life.','5. **Antioxidants**: Ingredients like **Cocos nucifera (coconut) oil** and **Tris (tetramethylhydroxypiperidinol) citrate** can offer skin or hair protection against environmental damage'],
        cons: ['1. **Sulfates (Sodium laureth sulfate)**: As with the first product, **Sodium laureth sulfate** can cause dryness and irritation, especially for those with sensitive skin.','2. **Parabens (Methylparaben, Propylparaben)**: Parabens are controversial due to their potential endocrine-disrupting properties, though they are still widely used in cosmetics.','3. **Synthetic Fragrance (Parfum)**: Fragrances may lead to allergic reactions or skin irritation in sensitive individuals.','4. **Cocamide MEA**: This surfactant can be irritating to some skin types and is derived from coconut oil, which might not be suitable for those with sensitivities.','5. **PEGs**: Similar to the first product, **PEG-150 distearate** is a synthetic compound that may not be preferred by those avoiding petrochemical derivatives.']
    },
    'img3.jpg': {
        pros: ['1. **Probiotics**: The presence of **live cultures** (such as Lactobacillus and Bifidobacterium) can promote healthy digestion and gut health.','2. **Lower Fat**: The use of **skim milk** and **low-fat ingredients** makes it a lower-calorie option compared to full-fat yogurts.','3. **High in Protein**: As a dairy product, yogurt provides a good source of protein, essential for muscle repair and overall health.','4. **Calcium**: Yogurt is a natural source of calcium, which is important for bone health.','5. **Lactase Enzyme**: The inclusion of **lactase** makes it easier to digest for people with mild lactose intolerance.'],
        cons: [' 1. **Added Sugar**: **Sugar** is included as an ingredient, which can contribute to unnecessary calorie intake and spikes in blood sugar.','2. **Gelatine**: While gelatine is used to give the yogurt its texture, it is not suitable for vegetarians or vegans.','3. **Artificial Additives**: **Thickeners**, **flavors**, and **acidity regulators** may be synthetic and not ideal for those preferring natural food products.','4. **Dairy Sensitivities**: Contains **milk and milk products**, which may cause issues for people with dairy allergies or lactose intolerance.','5. **Not Vegan**: Contains dairy, so it is unsuitable for vegan diets.']
    },
    'img4.jpg': {
        pros: ['1. **Indulgent and Tasty**: The combination of semi-sweet, bittersweet, and milk chocolate chips creates a rich and satisfying flavor.','2. **Quick Energy Source**: The sugar and chocolate provide a quick source of energy.','3. **Variety of Chocolate**: The different types of chocolate contribute to a balanced flavor and texture experience.','4. **Filling**: With a combination of sugars, fats, and chocolate, these cookies can be quite filling and satisfying as a treat.','n5. **Rich in Iron**: The enriched flour contains added iron, which helps with overall health.'],
        cons: ['1. **High in Sugar**: The cookies are loaded with sugar, which can contribute to weight gain and blood sugar issues.','2. **High in Fats**: The cookies contain a lot of oil and butter, which can contribute to excessive calorie intake and potentially raise cholesterol levels.','3. **Artificial Flavors**: The inclusion of **artificial flavor** may not appeal to those seeking natural ingredients.','4. **Possible Allergens**: Contains **wheat** (gluten), **soy**, and **milk**, which are common allergens.','5. **Nutritionally Low**: While tasty, the cookies offer little nutritional value other than simple carbs and fats.']
    },
    'img5.jpg': {
        pros: ['1. **High in Fiber**: Rolled oats and oat flour provide a good source of fiber, which can help with digestion and promote a feeling of fullness.','2. **Nutrient-Rich**: **Almonds** and **candied cranberries** provide healthy fats, vitamins, and antioxidants.','3. **Natural Sweeteners**: The inclusion of **honey** and **malt extract** adds natural sweetness compared to refined sugar.','4. **Convenient**: This product is easy to consume and could serve as a quick snack or breakfast.','5. **Source of Vitamins and Minerals**: Fortified with vitamins and minerals, which can contribute to overall nutrition.'],
        cons: ['1. **High in Sugar**: **Sugar**, **liquid glucose**, and other sweeteners can contribute to excessive calorie intake, leading to blood sugar spikes.','2. **Contains Palm Oil**: **Palmolein** (a form of palm oil) is often criticized for its environmental impact and high saturated fat content.','3. **Artificial Flavoring**: The **nature identical and artificial cream flavouring substances** could be a downside for those seeking all-natural ingredients.','4. **Allergen Risk**: Contains **gluten** and **almonds**, which can cause issues for individuals with allergies or sensitivities.','5. **Potential for Excessive Processed Ingredients**: Ingredients like **corn flour**, **dextrose**, and **maltodextrin** are processed and may not be as wholesome as natural alternatives.']
    },
    'img6.jpg': {
        pros: ['1. **Natural Vegetables**: Contains **onion**, **garlic**, and **ginger**, which are not only flavorful but also provide health benefits like anti-inflammatory and digestive properties.','2. **Spicy and Flavorful**: **Chillies**, **soy sauce**, and a range of **spices** provide a deep and rich flavor.','3. **Low in Calories**: The sauce is likely low in calories, especially when used as a condiment or flavoring.','4. **Preservatives for Shelf Life**: Ingredients like **preservatives** (e.g., **Sodium Benzoate**) help ensure a longer shelf life without spoiling.','5. **Contains Spices and Antioxidants**: **Ginger** and **garlic** are rich in antioxidants, which can be beneficial for the immune system.'],
        cons: ['1. **Added Sugar**: The presence of **sugar** adds unnecessary sweetness, which may not be desirable for those watching sugar intake.','2. **Sodium**: **Iodized salt**, **soya sauce**, and **flavor enhancers** contribute to high sodium content, which could be a concern for people with high blood pressure.','3. **Flavor Enhancers**: The inclusion of **monosodium glutamate (MSG)** (INS 627 & 631) and **artificial flavoring substances** may cause headaches or sensitivities in some individuals.','4. **Preservatives**: **Sodium benzoate** and other preservatives might have negative effects when consumed in large quantities.','5. **Allergen Risk**: Contains **soy** and may contain **gluten**, **celery**, **mustard**, and other allergens, which can be problematic for individuals with sensitivities.']
    },
    'img7.jpg': {
        pros: ['1. **Probiotics**: The **Greek yogurt** contains live cultures that promote digestive health and maintain gut flora.','2. **Rich in Protein**: Greek yogurt is high in protein, which is essential for muscle repair and general body functions.','3. **Good Source of Calcium**: Being dairy-based, it provides a good amount of **calcium**, which supports bone health.','4. **Blueberry Flavor**: The **blueberry syrup** provides a natural fruit flavor, with some antioxidants and vitamins.','5. **Less Sugary than Regular Yogurt**: The yogurt itself is likely to be less sweet compared to flavored yogurts, making it a healthier choice.'],
        cons: ['1. **Added Sugars**: The yogurt contains **sugar** in both the yogurt and **blueberry syrup**, which may contribute to excessive calorie intake.','2. **Artificial Additives**: **Pectin** and **citric acid** are processed ingredients used to thicken and preserve the syrup, potentially reducing the natural quality of the product.','3. **Not Vegan**: The product contains **dairy**, so it is unsuitable for those following a vegan or dairy-free diet.','4. **Low Fiber**: While the yogurt is protein-rich, it is relatively low in fiber compared to other snack options.','5. **Potential for Lactose Sensitivity**: People with lactose intolerance may experience discomfort when consuming this product.']
    },
    'img8.jpg': {
        pros: ['1. **Convenient and Quick**: Instant noodles are a quick and easy meal solution, especially for busy days.','2. **Flavorful**: The **spices** (onion, cumin, turmeric, clove) and **yummy masala mix** provide a rich, tasty experience.','3. **Vegetable Content**: Contains **dehydrated vegetables** like **onions** and **carrots**, which add some nutrition and texture to the noodles.','4. **Low Cost**: Instant noodles are affordable, making them accessible for people on a budget.','5. **Fortified with Salt and Minerals**: The presence of **iodized salt** ensures you are getting essential minerals.'],
        cons: ['1. **High in Sodium**: **Iodized salt**, **soy sauce**, and **flavor enhancers** contribute to high sodium content, which is not ideal for people with hypertension.','2. **Refined Carbs**: The noodles are made with **semolina** and **wheat gluten**, which are refined carbs, leading to a high glycemic index and potentially contributing to weight gain.','3. **Added Preservatives and Additives**: Ingredients like **maltodextrin**, **stabilizers**, and **anti-caking agents** are processed chemicals that can be less healthy.','4. **Low in Nutrients**: Instant noodles tend to be low in vitamins and minerals compared to other meal options.','5. **May Contain Allergens**: The product contains **wheat gluten**, **milk solids**, and may contain traces of **soy**, which can cause issues for individuals with allergies.']
    },
    
    // Add more images and their pros/cons as needed
};

// Extract text from image using Tesseract.js
extractTextButton.addEventListener('click', () => {
    const file = imageUpload.files[0];
    if (file) {
        extractTextButton.innerText = 'Extracting...';
        Tesseract.recognize(file, 'eng').then(({ data }) => {
            ingredientText.value = data.text;
            extractedText = data.text;
            extractTextButton.innerText = 'Extract Text';
        }).catch(error => {
            alert('Error extracting text: ' + error.message);
            extractTextButton.innerText = 'Extract Text';
        });
    } else {
        alert('Please upload an image first.');
    }
});

// Analyze ingredients and show pros/cons based on the selected image
analyzeButton.addEventListener('click', () => {
    if (!extractedText) {
        alert('Please extract text from an image first.');
        return;
    }

    analyzeButton.innerText = 'Analyzing...';

    // Get the selected image file
    const file = imageUpload.files[0];
    const fileName = file ? file.name.toLowerCase() : '';

    // Check if the selected image has predefined pros/cons
    if (imageProsAndCons[fileName]) {
        const { pros, cons } = imageProsAndCons[fileName];

        // Display the pros and cons
        fillProsConsTable(pros, cons);
    } else {
        alert('No pros and cons available for this image.');
    }

    analyzeButton.innerText = 'Analyze';
});

// Fill the pros and cons table
function fillProsConsTable(pros, cons) {
    const tbody = document.querySelector('#pros-cons-table tbody');
    tbody.innerHTML = ''; // Clear any existing rows

    // Loop through the pros and cons and add them to the table
    for (let i = 0; i < pros.length; i++) {
        const row = `<tr><td>${pros[i]}</td><td>${cons[i]}</td></tr>`;
        tbody.innerHTML += row;
    }
}
