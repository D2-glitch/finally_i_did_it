from flask import Flask, request, jsonify, render_template
import os
import json
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Allowed file extensions for image uploads
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

# Directory to save the uploaded images
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Nutritional data dictionary for different photos (you can customize it as needed)
nutritional_data_dict = {
    "img1.jpg": {
        "product_analysis": {
            "pros": [
                "Cleansing agents like Ammonium Lauryl Sulfate, Decyl Glucoside, and Cocamidopropyl Betaine effectively clean and remove dirt or oils from the skin or hair.",
                "Glycerin helps to retain moisture in the skin or hair, preventing dryness.",
                "Polyquaternium-7, Dimethicone, and Amodimethicone improve texture, smoothness, and shine, making hair or skin feel soft and silky.",
                "Fragrance and extracts like Cicer Arietinum Seed Extract provide a pleasant scent and potential antioxidant benefits.",
                "Potassium Sorbate and Sodium Benzoate extend shelf life and prevent bacterial growth in the product."
            ],
            "cons": [
                "Sulfates like Ammonium Lauryl Sulfate can be harsh on sensitive skin, stripping it of natural oils and causing dryness or irritation.",
                "Fragrances may contain allergens or irritants that can cause allergic reactions or skin sensitivities.",
                "Methylchloroisothiazolinone & Methylisothiazolinone preservatives are known to cause allergic reactions or skin irritation.",
                "PEG compounds like PEG-150 Distearate and PEG-45M are petrochemical derivatives, which may not be ideal for those avoiding synthetic chemicals.",
                "Non-biodegradable ingredients like Dimethicone and Acrylates Copolymer may harm aquatic life."
            ]
        }
    },
    "img2.jpg": {
        "product_analysis": {
            "pros": [
                "Coconut oil and Sweet almond oil provide nourishing fatty acids, moisturizing and soothing the skin or hair.",
                "Sodium laureth sulfate and Cocamidopropyl betaine effectively clean and remove impurities.",
                "Panthenol and Polyquaternium-10 improve hair manageability and smoothness.",
                "Phenoxyethanol and Methylparaben preserve the product and prevent microbial contamination.",
                "Coconut oil and Tris (tetramethylhydroxypiperidinol) citrate offer protection against environmental damage."
            ],
            "cons": [
                "Sodium laureth sulfate can cause dryness and irritation, especially for sensitive skin.",
                "Parabens like Methylparaben and Propylparaben are controversial due to their potential endocrine-disrupting properties.",
                "Synthetic fragrances may lead to allergic reactions or skin irritation in sensitive individuals.",
                "Cocamide MEA can be irritating and derived from coconut oil, which may not be suitable for those with sensitivities.",
                "PEG compounds like PEG-150 distearate are synthetic and may not be preferred by those avoiding petrochemical derivatives."
            ]
        }
    },
    "img3.jpg": {
        "product_analysis": {
            "pros": [
                "Live cultures promote healthy digestion and gut health.",
                "Skim milk and low-fat ingredients make this a lower-calorie option.",
                "Yogurt provides a good source of protein, essential for muscle repair and overall health.",
                "Natural source of calcium, important for bone health.",
                "Lactase enzyme makes it easier to digest for people with mild lactose intolerance."
            ],
            "cons": [
                "Sugar adds unnecessary calories and may cause blood sugar spikes.",
                "Gelatine is not suitable for vegetarians or vegans.",
                "Artificial additives like thickeners, flavors, and acidity regulators may not be ideal for natural food lovers.",
                "Contains milk and milk products, which may cause issues for people with dairy allergies or lactose intolerance.",
                "Not vegan-friendly due to dairy content."
            ]
        }
    },
    "img4.jpg": {
        "product_analysis": {
            "pros": [
                "The combination of semi-sweet, bittersweet, and milk chocolate chips creates a rich and satisfying flavor.",
                "Sugar and chocolate provide a quick source of energy.",
                "Different types of chocolate contribute to a balanced flavor and texture.",
                "Filling due to a combination of sugars, fats, and chocolate.",
                "Enriched flour contains added iron, which helps with overall health."
            ],
            "cons": [
                "Loaded with sugar, which can contribute to weight gain and blood sugar issues.",
                "High in fats from oils and butter, which can lead to excessive calorie intake and raise cholesterol levels.",
                "Artificial flavor may not appeal to those preferring natural ingredients.",
                "Contains common allergens like wheat (gluten), soy, and milk.",
                "Nutritionally low in beneficial nutrients, offering simple carbs and fats."
            ]
        }
    },
    "img5.jpg": {
        "product_analysis": {
            "pros": [
                "Rolled oats and oat flour provide a good source of fiber, aiding digestion and promoting fullness.",
                "Almonds and candied cranberries offer healthy fats, vitamins, and antioxidants.",
                "Natural sweeteners like honey and malt extract add sweetness compared to refined sugar.",
                "Convenient snack or breakfast option.",
                "Fortified with vitamins and minerals, contributing to overall nutrition."
            ],
            "cons": [
                "Sugar, liquid glucose, and other sweeteners contribute to excessive calorie intake and blood sugar spikes.",
                "Palmolein (palm oil) has a high saturated fat content and raises environmental concerns.",
                "Artificial cream flavoring substances reduce the product's natural quality.",
                "Contains gluten and almonds, which can trigger allergies or sensitivities.",
                "Excessive use of processed ingredients like corn flour, dextrose, and maltodextrin."
            ]
        }
    },
    "img6.jpg": {
        "product_analysis": {
            "pros": [
                "Contains natural vegetables like onion, garlic, and ginger, which offer health benefits like anti-inflammatory properties.",
                "Spices, soy sauce, and other condiments provide deep and rich flavor.",
                "Low in calories, especially when used as a condiment.",
                "Preservatives like sodium benzoate ensure a longer shelf life.",
                "Ginger and garlic are rich in antioxidants, supporting the immune system."
            ],
            "cons": [
                "Sugar adds unnecessary sweetness, which may not be desirable for some.",
                "High sodium content from iodized salt, soy sauce, and flavor enhancers may affect blood pressure.",
                "Flavor enhancers like monosodium glutamate (MSG) may cause headaches or sensitivities.",
                "Preservatives like sodium benzoate may have negative effects when consumed in large quantities.",
                "Contains allergens like soy, gluten, celery, mustard, and milk, which could be problematic for sensitive individuals."
            ]
        }
    },
    "img7.jpg": {
        "product_analysis": {
            "pros": [
                "Greek yogurt provides probiotics that promote digestive health.",
                "Rich in protein, which supports muscle repair and overall health.",
                "A good source of calcium for bone health.",
                "Blueberry syrup adds natural fruit flavor and antioxidants.",
                "Less sugary than regular yogurts, making it a healthier option."
            ],
            "cons": [
                "Added sugars in both the yogurt and blueberry syrup contribute to excessive calorie intake.",
                "Artificial additives like pectin and citric acid reduce the natural quality of the product.",
                "Contains dairy, making it unsuitable for those on a vegan or dairy-free diet.",
                "Relatively low in fiber compared to other snack options.",
                "People with lactose intolerance may experience discomfort."
            ]
        }
    },
    "img8.jpg": {
        "product_analysis": {
            "pros": [
                "Instant noodles are quick and convenient, ideal for busy days.",
                "Spices like onion, cumin, turmeric, and clove provide rich flavor.",
                "Contains dehydrated vegetables like onions and carrots, adding some nutrition and texture.",
                "Affordable, making them accessible to people on a budget.",
                "Fortified with iodized salt, providing essential minerals."
            ],
            "cons": [
                "High sodium content due to iodized salt, soy sauce, and flavor enhancers.",
                "Made with refined carbs like semolina and wheat gluten, contributing to a high glycemic index.",
                "Processed additives like maltodextrin, stabilizers, and anti-caking agents can be unhealthy.",
                "Low in vitamins and minerals compared to other meal options.",
                "Contains allergens like wheat gluten, milk solids, and may contain traces of soy."
            ]
        }
    }
}

# Ensure the directory exists
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Max file size: 16MB

# Helper function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def home():
    """Render the home page"""
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle image upload and return nutritional data"""
    try:
        # Check if the request contains the file
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'}), 400
        file = request.files['file']
        
        # If no file is selected, return an error
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400
        
        # If file is allowed, save it and extract data
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            # Lookup nutritional data based on the filename (or metadata you associate with the image)
            nutritional_data = nutritional_data_dict.get(filename)
            
            if not nutritional_data:
                return jsonify({'error': 'Nutritional data not available for this image'}), 404

            # Save the nutritional data in a JSON file (optional)
            file_name = f"{filename}_nutritional_data.json"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file_name)

            with open(file_path, 'w') as json_file:
                json.dump(nutritional_data, json_file, indent=4)

            # Return nutritional data as JSON to the frontend
            return jsonify(nutritional_data)

        else:
            return jsonify({'error': 'File type not allowed'}), 400

    except Exception as e:
        return jsonify({'error': 'Failed to process the file', 'details': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
